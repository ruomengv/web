"use strict";
const common_vendor = require("../common/vendor.js");
function getCurrentUser() {
  const userData = common_vendor.index.getStorageSync("user");
  return userData ? JSON.parse(userData) : null;
}
function isAdmin() {
  const user = getCurrentUser();
  return user && user.role === 0;
}
exports.getCurrentUser = getCurrentUser;
exports.isAdmin = isAdmin;
//# sourceMappingURL=../../.sourcemap/mp-weixin/utils/auth.js.map
