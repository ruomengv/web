"use strict";
const common_vendor = require("../../common/vendor.js");
const utils_date = require("../../utils/date.js");
const utils_auth = require("../../utils/auth.js");
const _sfc_main = common_vendor.defineComponent({
  data() {
    return {
      meeting: new UTSJSONObject({}),
      loading: true
    };
  },
  methods: {
    formatDate: utils_date.formatDate,
    goBack() {
      common_vendor.index.navigateBack();
    },
    getStatusText(status = null) {
      const statusMap = new UTSJSONObject({
        "scheduled": "已安排",
        "upcoming": "未开始",
        "ongoing": "进行中",
        "ended": "已结束"
      });
      return statusMap[status] || "未知状态";
    },
    // 填写参会回执
    fillReply() {
      const user = utils_auth.getCurrentUser();
      if (!user) {
        common_vendor.index.showToast({
          title: "请先登录",
          icon: "none"
        });
        return null;
      }
      common_vendor.index.__f__("log", "at pages/conference/detail.vue:90", "当前用户对象:", user);
      const userId = user.uid || user.id;
      if (!userId) {
        common_vendor.index.__f__("error", "at pages/conference/detail.vue:93", "用户ID不存在:", user);
        common_vendor.index.showToast({
          title: "用户信息异常，请重新登录",
          icon: "none"
        });
        return null;
      }
      common_vendor.index.__f__("log", "at pages/conference/detail.vue:100", `用户ID: ${userId}, 会议ID: ${this.meeting.id}, 操作: 点击填写回执`);
      common_vendor.index.navigateTo({
        url: `/pages/conference/registration?meetingId=${this.meeting.id}`
      });
    },
    // 加载会议详情（使用POST请求，符合后端接口要求）
    loadMeetingDetail(meetingId = null) {
      this.loading = true;
      common_vendor.index.request({
        url: "http://localhost:8081/api/meetings/getMeetingById",
        method: "POST",
        data: new UTSJSONObject({ id: meetingId }),
        success: (res) => {
          if (res.statusCode === 200) {
            this.meeting = res.data.data || res.data || new UTSJSONObject({});
          } else {
            common_vendor.index.showToast({ title: "加载失败", icon: "error" });
            setTimeout(() => {
              return common_vendor.index.navigateBack();
            }, 1500);
          }
        },
        fail: () => {
          common_vendor.index.showToast({ title: "网络错误", icon: "error" });
          setTimeout(() => {
            return common_vendor.index.navigateBack();
          }, 1500);
        },
        complete: () => {
          this.loading = false;
        }
      });
    }
  },
  onLoad(options) {
    this.loadMeetingDetail(options.id);
  }
});
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return common_vendor.e({
    a: common_vendor.o((...args) => $options.goBack && $options.goBack(...args)),
    b: $data.loading
  }, $data.loading ? {} : {
    c: common_vendor.t($data.meeting.name),
    d: common_vendor.t($options.formatDate($data.meeting.startTime)),
    e: common_vendor.t($options.formatDate($data.meeting.endTime)),
    f: common_vendor.t($data.meeting.organizer || "未知"),
    g: common_vendor.t($options.getStatusText($data.meeting.status)),
    h: $data.meeting.status === "scheduled" ? 1 : "",
    i: common_vendor.t($data.meeting.content || "暂无描述"),
    j: common_vendor.o((...args) => $options.fillReply && $options.fillReply(...args))
  }, {
    k: common_vendor.sei(common_vendor.gei(_ctx, ""), "view")
  });
}
const MiniProgramPage = /* @__PURE__ */ common_vendor._export_sfc(_sfc_main, [["render", _sfc_render], ["__scopeId", "data-v-47eddaf4"]]);
wx.createPage(MiniProgramPage);
//# sourceMappingURL=../../../.sourcemap/mp-weixin/pages/conference/detail.js.map
