"use strict";
const common_vendor = require("../../common/vendor.js");
const utils_auth = require("../../utils/auth.js");
const _sfc_main = common_vendor.defineComponent({
  data() {
    return {
      meetingId: "",
      registration: new UTSJSONObject({
        unit: "",
        name: "",
        gender: "male",
        phone: "",
        email: ""
      }),
      logs: []
    };
  },
  onLoad(options) {
    this.meetingId = options.meetingId;
    common_vendor.index.__f__("log", "at pages/conference/registration.vue:73", "接收到的会议ID:", this.meetingId);
    this.addLog("info", `页面加载成功，会议ID: ${this.meetingId}`);
    if (!this.meetingId) {
      this.addLog("error", "未获取到会议ID");
      common_vendor.index.showToast({
        title: "会议信息错误",
        icon: "none"
      });
      setTimeout(() => {
        common_vendor.index.navigateBack();
      }, 1500);
      return null;
    }
    const user = utils_auth.getCurrentUser();
    if (user) {
      this.addLog("info", `用户已登录，ID: ${user.uid}`);
    } else {
      this.addLog("warning", "用户未登录");
    }
  },
  methods: {
    goBack() {
      common_vendor.index.navigateBack();
    },
    onGenderChange(e = null) {
      this.registration.gender = e.detail.value;
      this.addLog("info", `性别选择: ${this.registration.gender}`);
    },
    submitForm() {
      if (!this.registration.name) {
        this.addLog("error", "姓名不能为空");
        common_vendor.index.showToast({
          title: "姓名不能为空",
          icon: "none"
        });
        return null;
      }
      if (!this.registration.phone) {
        this.addLog("error", "手机号码不能为空");
        common_vendor.index.showToast({
          title: "手机号码不能为空",
          icon: "none"
        });
        return null;
      }
      const user = utils_auth.getCurrentUser();
      if (!user || !user.uid) {
        this.addLog("error", "用户未登录或用户信息不完整");
        common_vendor.index.showToast({
          title: "请先登录",
          icon: "none"
        });
        return null;
      }
      const payload = new UTSJSONObject({
        userId: user.uid,
        meetingId: Number(this.meetingId),
        unit: this.registration.unit,
        name: this.registration.name,
        gender: this.registration.gender,
        phone: this.registration.phone,
        email: this.registration.email
      });
      common_vendor.index.__f__("log", "at pages/conference/registration.vue:148", "提交的数据:", payload);
      this.addLog("info", "正在提交参会回执...");
      common_vendor.index.showLoading({
        title: "提交中...",
        mask: true
      });
      common_vendor.index.request({
        url: "http://localhost:8081/api/meeting/registration",
        method: "POST",
        data: payload,
        success: (res) => {
          const responseData = typeof res.data === "string" ? res.data : UTS.JSON.stringify(res.data);
          if (res.statusCode === 200) {
            this.addLog("success", "提交成功");
            common_vendor.index.showToast({
              title: "提交成功",
              icon: "success"
            });
            setTimeout(() => {
              common_vendor.index.navigateBack();
            }, 1500);
          } else {
            this.addLog("error", `提交失败: ${responseData}`);
            common_vendor.index.showToast({
              title: `提交失败: ${responseData}`,
              icon: "none"
            });
          }
        },
        fail: (err) => {
          this.addLog("error", `网络错误: ${err.errMsg}`);
          common_vendor.index.showToast({
            title: "网络错误，请稍后再试",
            icon: "none"
          });
        },
        complete: () => {
          common_vendor.index.hideLoading();
          this.addLog("info", "请求完成");
        }
      });
    },
    // 添加日志方法
    addLog(type = null, message = null) {
      const time = (/* @__PURE__ */ new Date()).toLocaleTimeString();
      this.logs.push({
        type,
        time,
        message
      });
      if (this.logs.length > 20) {
        UTS.arrayShift(this.logs);
      }
    }
  }
});
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return common_vendor.e({
    a: common_vendor.o((...args) => $options.goBack && $options.goBack(...args)),
    b: $data.registration.unit,
    c: common_vendor.o(($event) => $data.registration.unit = $event.detail.value),
    d: $data.registration.name,
    e: common_vendor.o(($event) => $data.registration.name = $event.detail.value),
    f: $data.registration.gender === "male",
    g: $data.registration.gender === "female",
    h: common_vendor.o((...args) => $options.onGenderChange && $options.onGenderChange(...args)),
    i: $data.registration.phone,
    j: common_vendor.o(($event) => $data.registration.phone = $event.detail.value),
    k: $data.registration.email,
    l: common_vendor.o(($event) => $data.registration.email = $event.detail.value),
    m: common_vendor.o((...args) => $options.submitForm && $options.submitForm(...args)),
    n: $data.logs.length > 0
  }, $data.logs.length > 0 ? {
    o: common_vendor.f($data.logs, (log, index, i0) => {
      return {
        a: common_vendor.t(log.time),
        b: common_vendor.t(log.message),
        c: index
      };
    })
  } : {}, {
    p: common_vendor.sei(common_vendor.gei(_ctx, ""), "view")
  });
}
const MiniProgramPage = /* @__PURE__ */ common_vendor._export_sfc(_sfc_main, [["render", _sfc_render], ["__scopeId", "data-v-64b9ec62"]]);
wx.createPage(MiniProgramPage);
//# sourceMappingURL=../../../.sourcemap/mp-weixin/pages/conference/registration.js.map
