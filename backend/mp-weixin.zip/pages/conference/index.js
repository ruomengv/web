"use strict";
const common_vendor = require("../../common/vendor.js");
const utils_date = require("../../utils/date.js");
const _sfc_main = common_vendor.defineComponent({
  data() {
    return {
      searchKeyword: "",
      activeCategory: "all",
      categories: [
        new UTSJSONObject({ label: "全部", value: "all" }),
        new UTSJSONObject({ label: "会议研讨", value: "seminar" }),
        new UTSJSONObject({ label: "标准定制", value: "standard" }),
        new UTSJSONObject({ label: "技术培训", value: "training" }),
        new UTSJSONObject({ label: "工具研发", value: "tool" }),
        new UTSJSONObject({ label: "公益行动", value: "welfare" })
      ],
      meetings: [],
      loading: false
    };
  },
  computed: {
    filteredMeetings() {
      let filtered = this.meetings;
      if (this.activeCategory !== "all") {
        filtered = filtered.filter((meeting) => {
          return meeting.category === this.activeCategory;
        });
      }
      if (this.searchKeyword.trim()) {
        const keyword = this.searchKeyword.toLowerCase();
        filtered = filtered.filter((meeting) => {
          return (meeting.name || "").toLowerCase().includes(keyword) || (meeting.organizer || "").toLowerCase().includes(keyword) || (meeting.location || "").toLowerCase().includes(keyword);
        });
      }
      return filtered;
    }
  },
  methods: {
    formatDate: utils_date.formatDate,
    selectCategory(category = null) {
      this.activeCategory = category;
    },
    searchMeetings() {
    },
    getCategoryLabel(value = null) {
      const map = new UTSJSONObject({
        seminar: "会议研讨",
        standard: "标准定制",
        training: "技术培训",
        tool: "工具研发",
        welfare: "公益行动"
      });
      return map[value] || "其他";
    },
    goToMeetingDetail(meeting = null) {
      common_vendor.index.navigateTo({
        url: `/pages/conference/detail?id=${meeting.id}`
      });
      common_vendor.index.__f__("log", "at pages/conference/index.vue:111", "点击会议：", meeting);
    },
    loadMeetings() {
      this.loading = true;
      common_vendor.index.request({
        url: "http://localhost:8081/api/meetings/listAll",
        method: "GET",
        success: (res) => {
          if (res.statusCode === 200) {
            let data = res.data.data || res.data.list || res.data || [];
            const categoryMap = new UTSJSONObject({
              "会议研讨": "seminar",
              "标准定制": "standard",
              "技术培训": "training",
              "工具研发": "tool",
              "公益行动": "welfare"
            });
            this.meetings = data.map((item = null) => {
              return new UTSJSONObject(Object.assign(Object.assign({}, item), { category: categoryMap[item.category] || item.category }));
            });
          } else {
            common_vendor.index.showToast({ title: "加载失败", icon: "error" });
          }
        },
        fail: () => {
          common_vendor.index.showToast({ title: "网络错误", icon: "error" });
        },
        complete: () => {
          this.loading = false;
        }
      });
    }
  },
  onLoad() {
    this.loadMeetings();
  }
});
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return common_vendor.e({
    a: common_vendor.o((...args) => $options.searchMeetings && $options.searchMeetings(...args)),
    b: $data.searchKeyword,
    c: common_vendor.o(($event) => $data.searchKeyword = $event.detail.value),
    d: common_vendor.o((...args) => $options.searchMeetings && $options.searchMeetings(...args)),
    e: common_vendor.f($data.categories, (category, index, i0) => {
      return {
        a: common_vendor.t(category.label),
        b: index,
        c: $data.activeCategory === category.value ? 1 : "",
        d: common_vendor.o(($event) => $options.selectCategory(category.value), index)
      };
    }),
    f: common_vendor.f($options.filteredMeetings, (meeting, k0, i0) => {
      return {
        a: common_vendor.t(meeting.name),
        b: common_vendor.t($options.formatDate(meeting.startTime)),
        c: common_vendor.t(meeting.location || "待定"),
        d: common_vendor.t(meeting.organizer || "主办方"),
        e: common_vendor.t($options.getCategoryLabel(meeting.category)),
        f: meeting.id,
        g: common_vendor.o(($event) => $options.goToMeetingDetail(meeting), meeting.id)
      };
    }),
    g: $data.loading
  }, $data.loading ? {} : {}, {
    h: !$data.loading && $options.filteredMeetings.length === 0
  }, !$data.loading && $options.filteredMeetings.length === 0 ? {} : {}, {
    i: common_vendor.sei(common_vendor.gei(_ctx, ""), "view")
  });
}
const MiniProgramPage = /* @__PURE__ */ common_vendor._export_sfc(_sfc_main, [["render", _sfc_render], ["__scopeId", "data-v-54dcac07"]]);
wx.createPage(MiniProgramPage);
//# sourceMappingURL=../../../.sourcemap/mp-weixin/pages/conference/index.js.map
