"use strict";
const common_vendor = require("../../common/vendor.js");
const utils_auth = require("../../utils/auth.js");
const _sfc_main = common_vendor.defineComponent({
  data() {
    return {
      userLogged: false,
      userInfo: new UTSJSONObject({}),
      loginForm: new UTSJSONObject({
        username: "",
        password: ""
      }),
      defaultAvatar: "https://img.yzcdn.cn/vant/cat.jpeg"
    };
  },
  computed: {
    // 计算属性：判断用户是否为管理员
    isAdmin() {
      return utils_auth.isAdmin();
    }
  },
  methods: {
    handleLogin() {
      if (!this.loginForm.username || !this.loginForm.password) {
        common_vendor.index.showToast({ title: "请输入用户名和密码", icon: "none" });
        return null;
      }
      common_vendor.index.showLoading({ title: "登录中..." });
      common_vendor.index.request({
        url: "http://localhost:8081/api/auth/login",
        method: "POST",
        data: new UTSJSONObject({
          username: this.loginForm.username,
          password: this.loginForm.password
        }),
        success: (res) => {
          var _a, _b;
          common_vendor.index.hideLoading();
          if (res.statusCode === 200) {
            common_vendor.index.showToast({ title: "登录成功", icon: "success" });
            common_vendor.index.setStorageSync("user", UTS.JSON.stringify(res.data.user || res.data));
            this.userInfo = Object.assign(Object.assign({}, utils_auth.getCurrentUser()), { nickName: (_a = res.data.user) === null || _a === void 0 ? null : _a.nickname });
            this.userLogged = true;
            common_vendor.index.__f__("log", "at pages/me/index.vue:122", "登录成功，获取到的用户信息如下：", this.userInfo);
          } else {
            common_vendor.index.showToast({ title: ((_b = res.data) === null || _b === void 0 ? null : _b.message) || "登录失败", icon: "none" });
          }
        },
        fail: () => {
          common_vendor.index.hideLoading();
          common_vendor.index.showToast({ title: "网络错误，请重试", icon: "none" });
        }
      });
    },
    handleLogout() {
      common_vendor.index.showModal(new UTSJSONObject({
        title: "提示",
        content: "确定要退出登录吗？",
        success: (res) => {
          if (res.confirm) {
            common_vendor.index.request({
              url: "http://localhost:8081/api/auth/logout",
              method: "POST",
              success: () => {
                common_vendor.index.removeStorageSync("user");
                this.userLogged = false;
                this.userInfo = new UTSJSONObject({});
                this.loginForm = { username: "", password: "" };
                common_vendor.index.showToast({ title: "已退出登录", icon: "success" });
              },
              fail: () => {
                common_vendor.index.showToast({ title: "退出登录失败", icon: "none" });
              }
            });
          }
        }
      }));
    },
    loadUser() {
      const user = utils_auth.getCurrentUser();
      if (user) {
        this.userInfo = user;
        this.userLogged = true;
      }
    },
    goToUserAnalysis() {
      common_vendor.index.navigateTo({
        url: "/pages/me/userAnalysis"
      });
    },
    onLoad() {
      this.loadUser();
    }
  }
});
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return common_vendor.e({
    a: $data.userLogged
  }, $data.userLogged ? common_vendor.e({
    b: $data.userInfo.avatarUrl || $data.defaultAvatar,
    c: common_vendor.t($data.userInfo.nickName || $data.userInfo.username),
    d: $options.isAdmin
  }, $options.isAdmin ? {} : {}, {
    e: $options.isAdmin
  }, $options.isAdmin ? {
    f: common_vendor.o((...args) => $options.goToUserAnalysis && $options.goToUserAnalysis(...args))
  } : {}, {
    g: common_vendor.o((...args) => $options.handleLogout && $options.handleLogout(...args))
  }) : {
    h: $data.loginForm.username,
    i: common_vendor.o(($event) => $data.loginForm.username = $event.detail.value),
    j: $data.loginForm.password,
    k: common_vendor.o(($event) => $data.loginForm.password = $event.detail.value),
    l: common_vendor.o((...args) => $options.handleLogin && $options.handleLogin(...args))
  }, {
    m: common_vendor.sei(common_vendor.gei(_ctx, ""), "view")
  });
}
const MiniProgramPage = /* @__PURE__ */ common_vendor._export_sfc(_sfc_main, [["render", _sfc_render], ["__scopeId", "data-v-c8e26b33"]]);
wx.createPage(MiniProgramPage);
//# sourceMappingURL=../../../.sourcemap/mp-weixin/pages/me/index.js.map
