"use strict";
const common_vendor = require("../../common/vendor.js");
const _sfc_main = common_vendor.defineComponent({
  data() {
    return {
      meetings: [],
      registrations: [],
      showRegistrationList: false,
      currentMeetingId: null,
      currentMeetingName: ""
    };
  },
  onLoad() {
    this.getMeetings();
  },
  methods: {
    // 获取会议列表
    getMeetings() {
      common_vendor.index.request({
        url: "http://localhost:8081/api/meetings/listAll",
        method: "GET",
        success: (res) => {
          if (res.statusCode === 200) {
            this.meetings = res.data;
          } else {
            common_vendor.index.showToast({
              title: "获取会议列表失败",
              icon: "none"
            });
          }
        },
        fail: (err) => {
          common_vendor.index.__f__("error", "at pages/me/userAnalysis.vue:78", "请求错误:", err);
          common_vendor.index.showToast({
            title: "网络请求失败",
            icon: "none"
          });
        }
      });
    },
    // 显示报名列表
    showRegistrations(meetingId = null) {
      const meeting = UTS.arrayFind(this.meetings, (m) => {
        return m.id === meetingId;
      });
      if (!meeting) {
        common_vendor.index.showToast({
          title: "会议不存在",
          icon: "none"
        });
        return null;
      }
      this.currentMeetingId = meetingId;
      this.currentMeetingName = meeting.name;
      common_vendor.index.request({
        url: `http://localhost:8081/api/meeting/registration/${meetingId}/registrations`,
        method: "GET",
        success: (res) => {
          common_vendor.index.__f__("log", "at pages/me/userAnalysis.vue:105", "获取报名列表响应:", res);
          if (res.statusCode === 200) {
            this.registrations = res.data;
            this.showRegistrationList = true;
          } else {
            common_vendor.index.showToast({
              title: `获取报名信息失败: ${res.statusCode}`,
              icon: "none"
            });
          }
        },
        fail: (err) => {
          common_vendor.index.__f__("error", "at pages/me/userAnalysis.vue:117", "请求错误:", err);
          common_vendor.index.showToast({
            title: "网络请求失败",
            icon: "none"
          });
        }
      });
    },
    // 返回会议列表
    hideRegistrations() {
      this.showRegistrationList = false;
    },
    // 日期格式化函数
    formatDate(timestamp = null) {
      if (!timestamp)
        return "";
      const date = new Date(timestamp);
      return `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, "0")}-${date.getDate().toString().padStart(2, "0")}`;
    }
  }
});
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return common_vendor.e({
    a: !$data.showRegistrationList
  }, !$data.showRegistrationList ? {
    b: common_vendor.f($data.meetings, (meeting, k0, i0) => {
      return {
        a: common_vendor.t(meeting.name),
        b: common_vendor.t($options.formatDate(meeting.startTime)),
        c: common_vendor.t(meeting.organizer),
        d: meeting.id,
        e: common_vendor.o(($event) => $options.showRegistrations(meeting.id), meeting.id)
      };
    })
  } : {
    c: common_vendor.o((...args) => $options.hideRegistrations && $options.hideRegistrations(...args)),
    d: common_vendor.t($data.currentMeetingName),
    e: common_vendor.t($data.registrations.length),
    f: common_vendor.f($data.registrations, (reg, index, i0) => {
      return {
        a: common_vendor.t(index + 1),
        b: common_vendor.t(reg.name),
        c: common_vendor.t(reg.gender === "M" ? "男" : "女"),
        d: common_vendor.t(reg.unit),
        e: common_vendor.t(reg.phone),
        f: common_vendor.t(reg.email),
        g: reg.id
      };
    })
  }, {
    g: common_vendor.sei(common_vendor.gei(_ctx, ""), "view")
  });
}
const MiniProgramPage = /* @__PURE__ */ common_vendor._export_sfc(_sfc_main, [["render", _sfc_render], ["__scopeId", "data-v-46af89e0"]]);
wx.createPage(MiniProgramPage);
//# sourceMappingURL=../../../.sourcemap/mp-weixin/pages/me/userAnalysis.js.map
