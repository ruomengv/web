"use strict";
const common_vendor = require("../../common/vendor.js");
const _sfc_main = common_vendor.defineComponent({
  data() {
    return {
      baseUrl: "http://localhost:8081",
      searchQuery: "",
      newsList: [],
      currentNews: null,
      loadingMore: false,
      noMoreData: false,
      currentPage: 1,
      pageSize: 10,
      totalCount: 0,
      showNewsDetail: false
    };
  },
  methods: {
    getFullCoverUrl(cover = null) {
      if (!cover)
        return null;
      if (cover.startsWith("http"))
        return cover;
      return `${this.baseUrl}/image/${cover}`;
    },
    formatDate(dateStr = null) {
      if (!dateStr)
        return "";
      return dateStr.substring(0, 10);
    },
    searchNews() {
      this.currentPage = 1;
      this.noMoreData = false;
      this.loadNews(true);
    },
    loadNews(isRefresh = false) {
      if (this.loadingMore)
        return null;
      this.loadingMore = true;
      const requestData = new UTSJSONObject({
        page: this.currentPage,
        size: this.pageSize
      });
      if (this.searchQuery.trim()) {
        requestData.query = this.searchQuery.trim();
      }
      common_vendor.index.request({
        url: `${this.baseUrl}/api/news`,
        method: "GET",
        data: requestData,
        header: new UTSJSONObject({ "Content-Type": "application/json" }),
        success: (res) => {
          if (res.statusCode === 200) {
            const data = res.data;
            const listData = (data.list || []).filter((item = null) => {
              return item.status === 1;
            });
            const processedList = listData.map((item = null) => {
              return new UTSJSONObject(Object.assign(Object.assign({}, item), { cover: this.getFullCoverUrl(item.cover) }));
            });
            if (isRefresh) {
              this.newsList = processedList;
            } else {
              this.newsList = [...this.newsList, ...processedList];
            }
            this.totalCount = data.total || 0;
            this.noMoreData = this.newsList.length >= this.totalCount || listData.length < this.pageSize;
          } else {
            common_vendor.index.showToast({ title: "获取新闻失败", icon: "none" });
          }
        },
        fail: (err) => {
          common_vendor.index.__f__("error", "at pages/news/index.vue:139", "获取新闻失败:", err);
          common_vendor.index.showToast({ title: "网络错误，请重试", icon: "none" });
        },
        complete: () => {
          this.loadingMore = false;
          if (isRefresh && common_vendor.index.stopPullDownRefresh) {
            try {
              common_vendor.index.stopPullDownRefresh();
            } catch (e) {
              common_vendor.index.__f__("log", "at pages/news/index.vue:145", "停止下拉刷新失败:", e);
            }
          }
        }
      });
    },
    loadMoreNews() {
      if (this.noMoreData || this.loadingMore)
        return null;
      this.currentPage++;
      this.loadNews();
    },
    viewNewsDetail(news = null) {
      if (news.content) {
        this.currentNews = news;
        this.showNewsDetail = true;
      } else {
        this.fetchNewsDetail(news.id);
      }
    },
    fetchNewsDetail(newsId = null) {
      common_vendor.index.showLoading({ title: "加载中..." });
      common_vendor.index.request({
        url: `${this.baseUrl}/api/news/${newsId}`,
        method: "GET",
        header: new UTSJSONObject({ "Content-Type": "application/json" }),
        success: (res) => {
          if (res.statusCode === 200 && res.data) {
            this.currentNews = Object.assign(Object.assign({}, res.data), { cover: this.getFullCoverUrl(res.data.cover) });
            this.showNewsDetail = true;
          } else {
            common_vendor.index.showToast({ title: "获取新闻详情失败", icon: "none" });
          }
        },
        fail: (err) => {
          common_vendor.index.__f__("error", "at pages/news/index.vue:181", "获取新闻详情失败:", err);
          common_vendor.index.showToast({ title: "网络错误，请重试", icon: "none" });
        },
        complete: () => {
          common_vendor.index.hideLoading();
        }
      });
    },
    closeDetail() {
      this.showNewsDetail = false;
      this.currentNews = null;
    }
  },
  onLoad() {
    this.loadNews(true);
  },
  onReachBottom() {
    this.loadMoreNews();
  },
  onPullDownRefresh() {
    this.currentPage = 1;
    this.noMoreData = false;
    this.loadNews(true);
  }
});
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return common_vendor.e({
    a: common_vendor.o((...args) => $options.searchNews && $options.searchNews(...args)),
    b: $data.searchQuery,
    c: common_vendor.o(($event) => $data.searchQuery = $event.detail.value),
    d: common_vendor.o((...args) => $options.searchNews && $options.searchNews(...args)),
    e: common_vendor.f($data.newsList, (news, k0, i0) => {
      return common_vendor.e({
        a: $options.getFullCoverUrl(news.cover)
      }, $options.getFullCoverUrl(news.cover) ? {
        b: $options.getFullCoverUrl(news.cover)
      } : {}, {
        c: common_vendor.t(news.title),
        d: common_vendor.t(news.summary || news.content),
        e: common_vendor.t(news.author),
        f: common_vendor.t($options.formatDate(news.createTime)),
        g: news.id,
        h: common_vendor.o(($event) => $options.viewNewsDetail(news), news.id)
      });
    }),
    f: $data.loadingMore
  }, $data.loadingMore ? {} : {}, {
    g: $data.noMoreData && $data.newsList.length > 0
  }, $data.noMoreData && $data.newsList.length > 0 ? {} : {}, {
    h: !$data.loadingMore && $data.newsList.length === 0
  }, !$data.loadingMore && $data.newsList.length === 0 ? {} : {}, {
    i: $data.showNewsDetail
  }, $data.showNewsDetail ? common_vendor.e({
    j: common_vendor.t($data.currentNews.title),
    k: common_vendor.o((...args) => $options.closeDetail && $options.closeDetail(...args)),
    l: $options.getFullCoverUrl($data.currentNews.cover)
  }, $options.getFullCoverUrl($data.currentNews.cover) ? {
    m: $options.getFullCoverUrl($data.currentNews.cover)
  } : {}, {
    n: common_vendor.t($data.currentNews.author),
    o: common_vendor.t($options.formatDate($data.currentNews.createTime)),
    p: $data.currentNews.content
  }) : {}, {
    q: common_vendor.sei(common_vendor.gei(_ctx, ""), "view")
  });
}
const MiniProgramPage = /* @__PURE__ */ common_vendor._export_sfc(_sfc_main, [["render", _sfc_render], ["__scopeId", "data-v-52cd24e9"]]);
wx.createPage(MiniProgramPage);
//# sourceMappingURL=../../../.sourcemap/mp-weixin/pages/news/index.js.map
